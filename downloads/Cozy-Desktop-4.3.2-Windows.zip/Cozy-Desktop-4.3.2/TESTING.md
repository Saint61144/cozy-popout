# Cozy Desktop 4.3

Live Brave confirmed the previous failure as a missing native host. Retrying
with the Chrome-compatible registration reached the companion's Connected
handshake. The app now creates that registration as part of Brave setup.

The browser and desktop playback panels were condensed and hide inactive
controls. The native host, artwork transparency, message validation and
media behavior are checked separately using Windows and simulated browser
tests. The connection tab owns the native link. There is no service worker.

The archive contains only reviewed files. Local host manifests, user paths
and private signing material are excluded.
